﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;

namespace ClaimManagement
{
    public partial class ClaimsHistory : Window
    {
        public ClaimsHistory()
        {
            InitializeComponent();

            // Set the DataContext to the ClaimsDataModel instance or the current object (this)
            this.DataContext = this;

            // Initialize commands
            ApproveCommand = new RelayCommand(ApproveClaim, CanApproveClaim);
            DenyCommand = new RelayCommand(DenyClaim, CanDenyClaim);

            // Ensure the DataGrid binds to ClaimList
            claimsDataGrid.ItemsSource = ClaimsDataModel.Instance.ClaimList;
        }

        // Commands
        public ICommand ApproveCommand { get; set; }
        public ICommand DenyCommand { get; set; }

        // Approve claim method
        private void ApproveClaim(object parameter)
        {
            var claim = parameter as Claim;
            if (claim != null)
            {
                if (VerifyClaim(claim))
                {
                    claim.Status = "Approved";
                    MessageBox.Show($"Claim {claim.ClaimID} Approved successfully.");
                    claimsDataGrid.Items.Refresh();
                }
                else
                {
                    MessageBox.Show($"Claim {claim.ClaimID} did not meet the approval criteria.");
                }
            }
        }

        // Deny claim method
        private void DenyClaim(object parameter)
        {
            var claim = parameter as Claim;
            if (claim != null)
            {
                claim.Status = "Denied";
                MessageBox.Show($"Claim {claim.ClaimID} has been denied.");
                claimsDataGrid.Items.Refresh();
            }
        }

        // CanApproveClaim method
        private bool CanApproveClaim(object parameter)
        {
            return parameter is Claim claim && claim.Status != "Approved";
        }

        // CanDenyClaim method
        private bool CanDenyClaim(object parameter)
        {
            return parameter is Claim claim && claim.Status != "Denied";
        }

        // Verify claim method
        private bool VerifyClaim(Claim claim)
        {
            bool isValid = true;

            if (int.TryParse(claim.HoursWorked, out int hoursWorked) && hoursWorked > 100)
            {
                isValid = false;
                MessageBox.Show("Error: Hours worked cannot exceed 100 hours.");
            }

            if (decimal.TryParse(claim.HourlyRate, out decimal hourlyRate) && (hourlyRate < 50 || hourlyRate > 300))
            {
                isValid = false;
                MessageBox.Show("Error: Hourly rate must be between 50 and 300.");
            }

            return isValid;
        }

        // Generate Report method
        private void GenerateReport_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var approvedClaims = ClaimsDataModel.Instance.ClaimList.Where(c => c.Status == "Approved").ToList();

                if (approvedClaims.Count == 0)
                {
                    MessageBox.Show("No approved claims available for generating a report.");
                    return;
                }

                StringBuilder reportBuilder = new StringBuilder();
                reportBuilder.AppendLine("Approved Claims Report");
                reportBuilder.AppendLine("======================================");
                reportBuilder.AppendLine("Claim ID | First Name | Surname | Hours Worked | Hourly Rate | Total Payment");
                reportBuilder.AppendLine("-------------------------------------------------------");

                foreach (var claim in approvedClaims)
                {
                    decimal.TryParse(claim.HourlyRate, out decimal hourlyRate);
                    int.TryParse(claim.HoursWorked, out int hoursWorked);
                    decimal totalPayment = hourlyRate * hoursWorked;

                    reportBuilder.AppendLine($"{claim.ClaimID} | {claim.FirstName} | {claim.Surname} | {hoursWorked} | {hourlyRate:C} | {totalPayment:C}");
                }

                string documentsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                string filePath = Path.Combine(documentsPath, "ApprovedClaimsReport.txt");

                File.WriteAllText(filePath, reportBuilder.ToString());

                MessageBox.Show($"Report generated successfully at {filePath}", "Success");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while generating the report: {ex.Message}", "Error");
            }
        }

        // Back button method
        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            LecturerDashboard lecturerDashboard = new LecturerDashboard();
            lecturerDashboard.Show();
            this.Close();
        }
    }
}
