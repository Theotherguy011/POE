﻿using System.Collections.ObjectModel;

namespace ClaimManagement
{
    public class ClaimsDataModel
    {
        private static ClaimsDataModel _instance;
        public static ClaimsDataModel Instance => _instance ??= new ClaimsDataModel();

        // ObservableCollection to enable UI updates
        public ObservableCollection<Claim> ClaimList { get; set; }

        private ClaimsDataModel()
        {
            // Sample data
            ClaimList = new ObservableCollection<Claim>
            {
                new Claim { ClaimID = 1, FirstName = "John", Surname = "Doe", HoursWorked = "40", HourlyRate = "200", Status = "Pending" },
                new Claim { ClaimID = 2, FirstName = "Jane", Surname = "Smith", HoursWorked = "50", HourlyRate = "150", Status = "Pending" }
            };
        }
    }

    // Claim model
    public class Claim
    {
        public int ClaimID { get; set; }
        public string FirstName { get; set; }
        public string Surname { get; set; }
        public string HoursWorked { get; set; }
        public string HourlyRate { get; set; }
        public string Status { get; set; }

        public string FinalPayment {  get; set; }

        public string AdditionalNotes { get; set; }

        public string SupportingDocument { get; set; }

    }
}
