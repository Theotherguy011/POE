﻿using Microsoft.Win32;
using System;
using System.Windows;
using System.Windows.Controls;

namespace ClaimManagement
{
    public partial class LecturerDashboard : Window
    {
        private string uploadedFilePath = "";

        public LecturerDashboard()
        {
            InitializeComponent();
            this.DataContext = ClaimsDataModel.Instance;

            // Bind DataGrid to ClaimList
            claimsDataGrid.ItemsSource = ClaimsDataModel.Instance.ClaimList;
        }

        // Handle file upload
        private void Upload_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "PDF files (*.pdf)|*.pdf|Word Documents (*.docx)|*.docx|Excel Files (*.xlsx)|*.xlsx";
            if (openFileDialog.ShowDialog() == true)
            {
                uploadedFilePath = openFileDialog.FileName;
                uploadedFileNameTextBlock.Text = $"Uploaded: {System.IO.Path.GetFileName(uploadedFilePath)}";
            }
        }

        // Handle claim submission
        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            CalculatePayment(); // Ensure the final payment is calculated


            // Collect claim data
            string firstName = nameTextBox.Text;
            string surname = surnameTextBox.Text;
            string hoursWorked = hoursWorkedTextBox.Text;
            string hourlyRate = hourlyRateTextBox.Text;
            string finalPayment = finalPaymentTextBlock.Text;
            string additionalNotes = notesTextBox.Text;

            // Validation checks
            if (string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(surname) ||
                string.IsNullOrWhiteSpace(hoursWorked) || string.IsNullOrWhiteSpace(hourlyRate) ||
                string.IsNullOrWhiteSpace(finalPayment))
            {
                MessageBox.Show("Please fill in all required fields and ensure calculations are correct.");
                return;
            }

            if (!decimal.TryParse(hoursWorked, out _) || !decimal.TryParse(hourlyRate, out _))
            {
                MessageBox.Show("Please enter valid numeric values for hours worked and hourly rate.");
                return;
            }

            // Add new claim to shared model
            ClaimsDataModel.Instance.ClaimList.Add(new Claim
            {
                ClaimID = (ClaimsDataModel.Instance.ClaimList.Count + 1),
                FirstName = firstName,
                Surname = surname,
                HoursWorked = hoursWorked,
                HourlyRate = hourlyRate,
                FinalPayment = finalPayment,
                AdditionalNotes = additionalNotes,
                SupportingDocument = uploadedFilePath,
                Status = "Pending"
            });

            // Clear form after submission
            nameTextBox.Clear();
            surnameTextBox.Clear();
            hoursWorkedTextBox.Clear();
            hourlyRateTextBox.Clear();
            notesTextBox.Clear();
            finalPaymentTextBlock.Text = "R0.00";
            uploadedFileNameTextBlock.Text = "";
            uploadedFilePath = "";
        }

        // Auto-calculate final payment
        private void CalculateFinalPayment(object sender, RoutedEventArgs e)
        {
            if (decimal.TryParse(hoursWorkedTextBox.Text, out decimal hoursWorked) &&
                decimal.TryParse(hourlyRateTextBox.Text, out decimal hourlyRate))
            {
                decimal finalPayment = hoursWorked * hourlyRate;
                finalPaymentTextBlock.Text = $"R{finalPayment:F2}";
            }
            else
            {
                finalPaymentTextBlock.Text = "0.00";
            }
        }

        // Handle GotFocus and LostFocus for placeholder effect
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && textBox.Text == "Enter text here...")  // Default placeholder text
            {
                textBox.Clear();
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && string.IsNullOrWhiteSpace(textBox.Text))
            {
                CalculatePayment();
            }
        }

        // Back to MainWindow
        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
        private void CalculatePayment()
        {
            // Try parsing the Hours Worked and Hourly Rate from the textboxes
            if (decimal.TryParse(hoursWorkedTextBox.Text, out decimal hoursWorked) &&
                decimal.TryParse(hourlyRateTextBox.Text, out decimal hourlyRate))
            {
                // Calculate the final payment
                decimal finalPayment = hoursWorked * hourlyRate;

                // Display the calculated payment in the finalPaymentTextBlock
                finalPaymentTextBlock.Text = $"R{finalPayment:F2}";
            }
            else
            {
                // Reset to default if parsing fails
                finalPaymentTextBlock.Text = "R0.00";
            }
        }





    }

}
