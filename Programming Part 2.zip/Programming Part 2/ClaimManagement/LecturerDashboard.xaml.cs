﻿using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;

using System.Windows;
using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.IO;

using Microsoft.Win32;
using System.Windows;
using System.Collections.ObjectModel;

namespace ClaimManagement
{
    public partial class LecturerDashboard : Window
    {
        private string uploadedFilePath = "";

        public LecturerDashboard()
        {
            InitializeComponent();
            this.DataContext = ClaimsDataModel.Instance;
            claimsDataGrid.ItemsSource = ClaimsDataModel.Instance.ClaimList;
        }

        // Handle file upload
        private void Upload_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "PDF files (*.pdf)|*.pdf|Word Documents (*.docx)|*.docx|Excel Files (*.xlsx)|*.xlsx";
            if (openFileDialog.ShowDialog() == true)
            {
                uploadedFilePath = openFileDialog.FileName;
                uploadedFileNameTextBlock.Text = $"Uploaded: {System.IO.Path.GetFileName(uploadedFilePath)}";
            }
        }

        // Handle claim submission
        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            // Collect claim data
            string firstName = nameTextBox.Text;
            string surname = surnameTextBox.Text;
            string hoursWorked = hoursWorkedTextBox.Text;
            string hourlyRate = hourlyRateTextBox.Text;
            string additionalNotes = notesTextBox.Text;

            // Simple validation
            if (string.IsNullOrWhiteSpace(hoursWorked) || string.IsNullOrWhiteSpace(hourlyRate))
            {
                MessageBox.Show("Please fill in all required fields.");
                return;
            }

            // Add new claim to shared model
            ClaimsDataModel.Instance.ClaimList.Add(new Claim
            {
                ClaimID = (ClaimsDataModel.Instance.ClaimList.Count + 1).ToString(),
                FirstName = firstName,
                Surname = surname,
                HoursWorked = hoursWorked,
                HourlyRate = hourlyRate,
                AdditionalNotes = additionalNotes,
                SupportingDocument = uploadedFilePath,
                Status = "Pending"
            });

            // Clear form after submission
            nameTextBox.Clear();
            surnameTextBox.Clear();
            hoursWorkedTextBox.Clear();
            hourlyRateTextBox.Clear();
            notesTextBox.Clear();
            uploadedFileNameTextBlock.Text = "";
            uploadedFilePath = "";
        }

        // Back to MainWindow
        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}



