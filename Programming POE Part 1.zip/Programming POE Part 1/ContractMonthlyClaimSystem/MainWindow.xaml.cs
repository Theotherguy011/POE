﻿using System.Windows;

namespace ContractMonthllyClaimSystem
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LecturerDashboardButton_Click(object sender, RoutedEventArgs e)
        {
            // Create an instance of the LecturerDashboard window
            LecturerDashboard lecturerDashboard = new LecturerDashboard();

            // Show the Lecturer Dashboard window
            lecturerDashboard.Show();

            // Optionally, close the current window
            this.Close();
        }
    }

    internal class LecturerDashboard
    {
        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}
